$(document).ready(function(){
    $('button').click(function(){
        $('tr:even').css("background-color", "yellow");
    });
});

                        // dblClick() method - double click to hide the elements


$(document).ready(function(){
    $('p').dblclick(function(){
        $(this).hide() ; 
    }) ; 
}) ; 



                            // <!-- mouseenter() and mouseleave() method -->

$(document).ready(function(){
    $('#para').mouseenter(function(){
        alert('You hovered on paragrpah') ; 
    }) ; 

    $('#para2').mouseleave(function(){
        alert('Bye! You now leave paragraph element') ; 
    }) ; 
}) ; 



                                            // hover() method

    
                                    
$(document).ready(function(){
    $('p').hover(function(){
        alert('Entering paragraph element')
    },
    function(){
        alert('Leaving paragraph element')
    }
    )
})



                                            // focus() & blur() method



    $(document).ready(function(){
        $('input').focus(function(){
            $(this).css("background-color","yellow") ; 
        }) ; 
        $('input').blur(function(){
            $(this).css("background-color", "blue") ; 
        }) ; 
    })